import React from 'react';

const Inicio = () => {
    return (
        <div className="container text-center mt-5">
            <h1>Bienvenido a la tienda de ropa a medida</h1>
            <p>Descubre nuestro servicio personalizado.</p>
        </div>
    );
};

export default Inicio;
