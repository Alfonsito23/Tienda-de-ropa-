import React, { useState } from 'react';

const FormularioMedidas = () => {
    const [medidas, setMedidas] = useState({ cintura: '', largo: '', ancho: '' });

    const handleChange = (e) => {
        setMedidas({ ...medidas, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(medidas);
    };

    return (
        <div className="container mt-4">
            <h2>Formulario de Medidas</h2>
            <form onSubmit={handleSubmit}>
                <input type="text" name="cintura" placeholder="Cintura (cm)" onChange={handleChange} className="form-control mb-2" />
                <input type="text" name="largo" placeholder="Largo (cm)" onChange={handleChange} className="form-control mb-2" />
                <input type="text" name="ancho" placeholder="Ancho (cm)" onChange={handleChange} className="form-control mb-2" />
                <button type="submit" className="btn btn-primary">Guardar</button>
            </form>
        </div>
    );
};

export default FormularioMedidas;
